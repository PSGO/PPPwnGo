# Changelog

## v1.1
- Improved stability and ftp service

## v1.0
- Public release