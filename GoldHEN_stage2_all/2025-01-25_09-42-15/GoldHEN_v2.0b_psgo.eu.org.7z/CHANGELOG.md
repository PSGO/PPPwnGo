# Changelog

## v2.0b
- Added BinLoader server (beta version)
- Added UI menu
- Improved stability and FTP server
- Fixed trophy timestamps

## v1.1
- Improved stability and FTP server

## v1.0
- Public release