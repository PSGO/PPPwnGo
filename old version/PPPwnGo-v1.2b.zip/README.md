- requires windows>=7.

- Just demo, don’t have too high expectations, the current success rate is not high, please wait patiently.

- If pppwn.py is updated later, there is no need to update the exe. Directly overwrite "pppwn.py", "offsets.py" in the root directory, and the bin files in the "stage1" and "stage1" folders.


1. Open the "先装环境！" folder and install the three items inside
2. Connect PS4 and PC using a network cable, enter PS4 Settings-Network-Set Internet Connection-Use Lan-Customize-PPPOE, and fill in a name and password.
3. Run "PPPwnGo.exe", select the PS4 version and the corresponding network card, generally the default is fine (unless you have multiple network cards), click the "Go" button
4. Click to enter "Test Internet" in the PS4 network
5. When the execution is completed, "done" will be displayed, and "PPPwn" will pop up in the upper left corner of PS4. If it is stuck, fails, crashes or loses power, repeat 3&4

Special thanks Andy for his efforts!



----------------------------------------------------------------------------------------



- 要求windows>=7
- Just demo，不要有过高期待，当前成功率并不高，耐心等待~
- 如果后续pppwn.py有更新，无需更新exe，直接覆盖根目录的“pppwn.py”、“offsets.py”，以及“stage1”“stage1”中的bin文件

1. 打开“先装环境！”文件夹，安装里面的三项
2. 把PS4和PC使用网线连接，进入PS4设置-网络-设定互联网连接-使用Lan-定制-PPPOE，随便填写一个名称和密码
3. 运行“PPPwnGo.exe”，选择PS4版本和相应的网卡，一般默认就可以（除非你有多个网卡），点击“Go”按钮
4. 在PS4网络中点击进入“测试互联网”
5. 等待执行结束会显示“done”，PS4左上角会弹出“PPPwned”，如果卡住、失败、死机或断电，重复3&4


再次特别感谢阮·Andy的付出！
