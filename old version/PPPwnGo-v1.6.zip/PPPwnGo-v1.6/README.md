Supported versions are:

FW 9.00 with GoldHEN / 9.03 / 9.04 / 9.50 / 9.60 / 10.00 / 10.01 / 10.50 / 10.70 / 10.71 / 11.00

- requires windows>=7.

- Just demo, don’t have too high expectations, the current success rate is not high, please wait patiently.

- If pppwn.py is updated later, there is no need to update the exe. Directly overwrite "pppwn.py"、 "offsets.py" in the main directory & bin of “PS4_stage_bin_all”folder


1. Open the "Python!" folder and install all（install the latest version of python）
2. Open the "PS4_GoldHEN_all" folder, put the corresponding version of payload.bin into the root directory of the exfat format U disk, and insert it into the PS4
3. Connect PS4 and PC using a network cable, enter PS4 Settings-Network-Set Internet Connection-Use Lan-Customize-PPPOE, and fill in a name and password.
4. Run "PPPwnGo.exe", select the PS4 version and the corresponding network card, generally the default is fine (unless you have multiple network cards), click the "Go" button
5. Click to enter "Test Internet" in the PS4 network
6. When the execution is completed, "done" will be displayed, and "PPPwn" will pop up in the upper left corner of PS4. If it is stuck, fails, crashes or loses power, repeat 4&5，if it fails more than 3 times in a row, please restart PS4 and PC.

Special thanks Andy for his efforts!



----------------------------------------------------------------------------------------

支持的版本：

FW 9.00 可注入GoldHEN / 9.03 / 9.04 / 9.50 / 9.60 / 10.00 / 10.01 / 10.50 / 10.70 / 10.71 / 11.00

- 要求 windows>=7
- Just demo，不要有过高期待，当前成功率并不高，耐心等待~
- 如果后续pppwn.py和stage.bin有更新，无需更新exe，直接覆盖根目录的“pppwn.py”、“offsets.py”和“PS4_stage_bin_all”中的bin

1. 打开“Python!”文件夹，安装里面的内容，建议安装最新版的python
2. 打开“PS4_GoldHEN_all”文件夹，把对应版本的payload.bin放入exfat格式的U盘根目录，插入PS4
3. 把PS4和PC使用网线连接，进入PS4设置-网络-设定互联网连接-使用Lan-定制-PPPOE，随便填写一个名称和密码
4. 运行“PPPwnGo.exe”，选择PS4版本和相应的网卡，一般默认就可以（除非你有多个网卡），点击“Go”按钮
5. 在PS4网络中点击进入“测试互联网”
6. 等待执行结束会显示“done”，PS4左上角会弹出“PPPwned”，如果卡住、失败、死机或断电，重复4&5，连续超过3次失败，请重启PS4和PC


再次特别感谢阮·Andy的付出！
