运行PPPwnGo之前，把对应版本的payload.bin放入exfat格式的U盘根目录，插入PS4
----------------------------------
Before running PPPwnGo, put payload.bin into the root directory of the exfat USB and insert it into PS4